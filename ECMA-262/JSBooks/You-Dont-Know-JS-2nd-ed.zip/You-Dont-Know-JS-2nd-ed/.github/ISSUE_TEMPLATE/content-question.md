---
name: Content Question
about: Ask a question about something you read in the books?
labels:

---

**Yes, I promise I've read the [Contributions Guidelines](https://github.com/getify/You-Dont-Know-JS/blob/master/CONTRIBUTING.md)** (please feel free to remove this line).

----

**Please type "I already searched for this issue":**

**Edition:** (1st or 2nd)

**Book Title:**

**Chapter:**

**Section Title:**

**Question:**
