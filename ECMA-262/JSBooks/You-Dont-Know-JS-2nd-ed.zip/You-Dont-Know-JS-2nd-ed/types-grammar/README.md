# You Don't Know JS Yet: Types & Grammar - 2nd Edition

| NOTE: |
| :--- |
| Work in progress |

[Table of Contents](toc.md)

* [Foreword](foreword.md) (by TBA)
* [Preface](../preface.md)
* [Chapter 1: Primitive Values](ch1.md)
* [Chapter 2: Primitive Behaviors](ch2.md)
* [Chapter 3: Object Values](ch3.md)
* [Chapter 4: Coercing Values](ch4.md)
* Chapter 5: TODO
