# 你不知道的JavaScript:  Up & Going

<img src="cover.jpg" width="300">

-----

**[从O'Reilly购买电子/纸质版](http://shop.oreilly.com/product/0636920039303.do)**

-----

[目录](toc.zh.md)

* [前言](foreword.md) (by [Jenn Lukas](http://jennlukas.com))
* [序](../preface.md)
* [第一章: 走进编程](ch1.md)
* [第二章: 走进JavaScript](ch2.md)
* [第三章: 走进你不知道的JavaScript](ch3.md)
* [附录 A: 致谢](apA.md)