var x = 1;
console.log('x is', x);
