/* 通过获取mybanner_ist子元素生成div，将div存放到一个nybanner_box的div中 */
//获取li元素,生成div,
/* 获取mybanner高度宽度,设置成多少倍 */

var mybanner=document.querySelectorAll(".mybanner");
var mybanner_width=mybanner.clientWidth;
var mybanner_height=mybanner.clientHeight;

var imgs=document.querySelectorAll(".mybanner_ist>li");
var div=document.createElement('div');
for(var i=0;i<imgs.length;i++){
	
	
	
}
