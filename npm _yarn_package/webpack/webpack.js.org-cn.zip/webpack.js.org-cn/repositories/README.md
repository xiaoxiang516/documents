# webpack documentation repositories

The files in this directory are auto generated from `src/utilities/fetch-package-repos.js` and should not be edited by hand. Any manual changes will be overwritten by the automation next time it runs.
