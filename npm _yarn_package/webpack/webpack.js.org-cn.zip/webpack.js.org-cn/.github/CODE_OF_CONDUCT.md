## Code of Conduct

At webpack and all webpack/webpack-contrib repositories we follow the
[JSFoundation Code of Conduct][1]. Please adhere to the guidelines there and
feel free to report any violation of them to the @webpack/core-team,
@webpack/documentation-team, or <conduct@js.foundation>.

[1]: https://github.com/openjs-foundation/code-and-learn/blob/master/CODE_OF_CONDUCT.md
