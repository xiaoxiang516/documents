// contributors 404
export const contributorsNotFound = [
  'bartushek',
  'rynclark',
  'henriquea',
  'makuzaverite',
  'MijaelWatts',
  'Kolhar730',
  'grrizzly',
  'maxloh',
  'varunjayaraman',
];
