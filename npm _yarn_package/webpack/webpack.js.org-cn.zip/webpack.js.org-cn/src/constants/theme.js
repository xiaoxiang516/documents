export const THEME = {
  DARK: 'dark',
  LIGHT: 'light',
};

export const THEME_LOCAL_STORAGE_KEY = 'theme';
