const isClient = window !== undefined && window.document !== undefined;

module.exports = isClient;
