webpackJsonp([0],[
/* 0 */,
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

var $ = __webpack_require__(0);
$('h1').text('Hello World');


/***/ })
],[1]);