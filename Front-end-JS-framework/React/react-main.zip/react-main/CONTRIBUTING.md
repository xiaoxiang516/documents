# Contributing to React

Want to contribute to React? There are a few things you need to know.  

We wrote a **[contribution guide](https://reactjs.org/docs/how-to-contribute.html)** to help you get started.
